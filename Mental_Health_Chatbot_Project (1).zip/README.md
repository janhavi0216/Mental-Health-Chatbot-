# Mental Health Chatbot 💬

This is a beginner-level chatbot built using Python and Gradio.  
It provides motivational and supportive quotes based on the user's mood.

## 👩‍💻 Features:
- Mood detection
- Motivational quotes
- Timestamped response

## 🛠️ Tools Used:
- Python
- Gradio
- datetime module

## 🚀 How to Run:
Just run the notebook and use the dropdown to select your mood. The bot will reply with a positive message.
